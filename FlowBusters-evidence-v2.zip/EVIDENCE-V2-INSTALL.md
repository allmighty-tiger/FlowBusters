# Evidence update v2

Apply on the POC branch, not main. This ZIP contains the prepared POC source
changes plus the evidence executor update; it is not a full repository.
Review `git diff` before committing, especially if you made other local edits.

1. Extract into the repository root (matching source files are replaced).
2. Run `python3 -m unittest discover -s backend/tests -v`.
3. In `frontend`, run `npm run build`.
4. Restart backend and frontend. Start a NEW assessment on the authorized,
   deliberately vulnerable test fixture. Old missing captures cannot be restored.

The Prober instructions now require `crew/scripts/verified_delete.py` for the
supported approved-item deletion predicate. It runs GET / DELETE / GET and
writes `reports/<flow>/evidence/<finding_id>.json`. App-specific URLs, JSON paths,
session headers and item ID must be derived from the recording. This is still
an agent-directed invocation, not an automatic generic application adapter.
Do not separately delete the same item before invoking the executor.

The backend merges captures by exact finding ID, persists the normalized final
report and displays the captured request/response sequence. Remediation can be
stored directly on that same capture. Duplicate IDs are not arbitrarily selected.

Confirmed requires a supplied user/specification rule, a complete collection,
an isolated test resource, and successful compatible before/after reads.
The older heuristic state-lock probe now retains its inferred rule as inferred;
it cannot manufacture specification authority and auto-confirm it.

Validated locally: 20 Python tests including six real local HTTP-server capture
and report-ingestion tests; TypeScript and production build. NOT validated:
full AI-agent assessment on your computer or visual rendering in a browser.
Browser reopening after Finish Recording is not addressed by this update.

Expected new report: status visible while collapsed; confirmed / needs-review
counts separate; captured evidence for the deletion check contains three pairs
when all requests completed. A 500 can still be confirmed if deletion occurred;
a 200 without deletion is not reproduced; failed state reads are check errors.

No credentials or run data are included. Do not commit the executor CONFIG:
it may contain authorization headers. Captured response bodies can contain
sensitive data; inspect and redact before sharing.
