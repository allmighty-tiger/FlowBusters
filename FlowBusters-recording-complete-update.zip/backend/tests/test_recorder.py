import asyncio
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch, AsyncMock
from backend.runtime.recorder import record, RecordingError, manifest_ids

ROOT = Path(__file__).resolve().parents[2]


class RecorderTests(unittest.IsolatedAsyncioTestCase):
    async def run_recording(self, mode):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = Path(tmp.name)
        (root / 'crew/scripts').mkdir(parents=True)
        shutil.copy(ROOT / 'crew/scripts/synthesize_har.py', root / 'crew/scripts/synthesize_har.py')
        (root / 'scope.json').write_text(json.dumps({'allowed_domains': ['http://fixture.test'], 'allowed_paths_prefix': ['*']}))
        mcp = root / 'mcp.json'
        mcp.write_text(json.dumps({'mcpServers': {'playwright': {'command': sys.executable,
            'args': [str(ROOT / 'backend/tests/recorder_mcp_fixture.py'), mode]}}}))
        config = SimpleNamespace(target_url='http://fixture.test', flow_name='test', overall_timeout=10, auto_complete=False)
        opened = asyncio.Event()
        task = asyncio.create_task(record(config, root, mcp, os.environ,
            lambda text: opened.set() if text.startswith('Browser ready') else None))
        await asyncio.wait_for(opened.wait(), 3)
        # No model process exists. Backend holds the MCP process until user Finish.
        await asyncio.sleep(0.05)
        self.assertFalse(task.done())
        calls = (root / 'calls.jsonl').read_text()
        self.assertNotIn('browser_close', calls)
        self.assertNotIn('browser_network_requests', calls)
        (root / 'recording_done.marker').write_text('user finished')
        if mode == 'missing':
            with self.assertRaises(RecordingError):
                await task
            self.assertFalse((root / 'recording_validated.marker').exists())
            self.assertNotIn('browser_close', (root / 'calls.jsonl').read_text())
            self.assertEqual(json.loads((root / 'flows/test/har_data/capture_manifest.json').read_text())['missing'], [{'index': 3, 'part': 'response-body'}])
        else:
            await task
            self.assertTrue((root / 'recording_validated.marker').exists())
            har = json.loads((root / 'flows/test/recording.har').read_text())
            self.assertEqual(len(har['log']['entries']), 2)
            self.assertTrue(all(e['response']['content']['text'] for e in har['log']['entries']))
            calls = [json.loads(line) for line in (root / 'calls.jsonl').read_text().splitlines()]
            self.assertEqual(calls[-1]['name'], 'browser_close')
            if mode == 'retry':
                self.assertEqual(sum(c['name'] == 'browser_network_request' and c['args'].get('index') == 3 and c['args'].get('part') == 'response-body' for c in calls), 2)

    async def test_backend_owns_recording_until_finish(self):
        await self.run_recording('normal')

    async def test_missing_body_retried_before_close(self):
        await self.run_recording('retry')

    async def test_permanent_missing_body_stops_pipeline(self):
        await self.run_recording('missing')

    def test_manifest_preserves_nonconsecutive_ids(self):
        self.assertEqual(manifest_ids('3. [POST] /login\n7. [GET] /items'), [3, 7])
        with self.assertRaises(RecordingError):
            manifest_ids('unknown format')

    async def test_failed_recording_never_launches_agent(self):
        from backend.runtime.crew_runner import CrewConfig, run_crew
        with tempfile.TemporaryDirectory() as temp:
            config = CrewConfig(target_url='http://fixture.test', flow_name='test',
                run_dir=temp, crew_dir=str(ROOT / 'crew'), mcp_config='unused.json',
                claude_bin='claude', model='test', api_key='', display=':0',
                phase_timeout=10, overall_timeout=10)
            with patch('backend.runtime.crew_runner.record', AsyncMock(side_effect=RecordingError('Incomplete body capture'))), patch('backend.runtime.crew_runner.asyncio.create_subprocess_exec', AsyncMock()) as spawn:
                result = await run_crew(config, lambda event: None)
                spawn.assert_not_called()
                self.assertIn('Incomplete body capture', result['error'])
