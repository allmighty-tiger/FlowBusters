"""Offline stdio MCP fixture: no browser or AI service."""
import json
import sys
from pathlib import Path

mode = sys.argv[1]
root = Path.cwd()
attempts = {}
snapshots = 0
for line in sys.stdin:
    message = json.loads(line)
    if 'id' not in message:
        continue
    method = message['method']
    result = {}
    if method == 'tools/list':
        result = {'tools': [{'name': name} for name in ['browser_navigate', 'browser_snapshot',
            'browser_network_requests', 'browser_network_request', 'browser_close']]}
    if method == 'tools/call':
        name = message['params']['name']
        args = message['params']['arguments']
        with (root / 'calls.jsonl').open('a') as log:
            log.write(json.dumps({'name': name, 'args': args}) + '\n')
        if name == 'browser_snapshot':
            snapshots += 1
            if mode == 'snapshot_error' or (mode == 'final_snapshot_error' and snapshots == 2):
                result = {'isError': True, 'content': [{'type': 'text', 'text': 'Target page has been closed'}]}
        if name == 'browser_network_requests':
            Path(args['filename']).write_text('3. [GET] http://fixture.test/api/data => [200] OK\n5. [GET] http://fixture.test/api/other => [200] OK\n')
        if name == 'browser_network_request':
            index = args['index']
            part = args.get('part')
            key = (index, part)
            attempts[key] = attempts.get(key, 0) + 1
            if index == 3 and part == 'response-body' and (mode == 'missing' or (mode == 'retry' and attempts[key] == 1)):
                result = {'isError': True}
            elif part:
                Path(args['filename']).write_text('{"ok": true}' if part == 'response-body' else '')
            else:
                Path(args['filename']).write_text(f'#'+str(index)+' [GET] http://fixture.test/api/data\n  General\n    status: [200] OK\n    mimeType: application/json\n  Response headers\n    content-type: application/json\n')
        if name == 'browser_close':
            if not (root / 'flows/test/recording.har').exists():
                result = {'isError': True}
    print(json.dumps({'jsonrpc': '2.0', 'id': message['id'], 'result': result}), flush=True)
