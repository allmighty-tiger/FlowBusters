import asyncio
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch, AsyncMock
from backend.runtime.recorder import record, RecordingError, manifest_ids, McpClient, optional_snapshot

ROOT = Path(__file__).resolve().parents[2]


class RecorderTests(unittest.IsolatedAsyncioTestCase):
    async def run_recording(self, mode):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = Path(tmp.name)
        (root / 'crew/scripts').mkdir(parents=True)
        shutil.copy(ROOT / 'crew/scripts/synthesize_har.py', root / 'crew/scripts/synthesize_har.py')
        (root / 'scope.json').write_text(json.dumps({'allowed_domains': ['http://fixture.test'], 'allowed_paths_prefix': ['*']}))
        mcp = root / 'mcp.json'
        mcp.write_text(json.dumps({'mcpServers': {'playwright': {'command': sys.executable,
            'args': [str(ROOT / 'backend/tests/recorder_mcp_fixture.py'), mode]}}}))
        config = SimpleNamespace(target_url='http://fixture.test', flow_name='test', overall_timeout=10, auto_complete=False)
        opened = asyncio.Event()
        task = asyncio.create_task(record(config, root, mcp, os.environ,
            lambda text: opened.set() if text.startswith('Browser ready') else None))
        await asyncio.wait_for(opened.wait(), 3)
        # No model process exists. Backend holds the MCP process until user Finish.
        await asyncio.sleep(0.05)
        self.assertFalse(task.done())
        calls = (root / 'calls.jsonl').read_text()
        self.assertNotIn('browser_close', calls)
        self.assertNotIn('browser_network_requests', calls)
        (root / 'recording_done.marker').write_text('user finished')
        if mode == 'missing':
            with self.assertRaises(RecordingError):
                await task
            self.assertFalse((root / 'recording_validated.marker').exists())
            self.assertNotIn('browser_close', (root / 'calls.jsonl').read_text())
            self.assertEqual(json.loads((root / 'flows/test/har_data/capture_manifest.json').read_text())['missing'], [{'index': 3, 'part': 'response-body'}])
        else:
            await task
            self.assertTrue((root / 'recording_validated.marker').exists())
            har = json.loads((root / 'flows/test/recording.har').read_text())
            self.assertEqual(len(har['log']['entries']), 2)
            self.assertTrue(all(e['response']['content']['text'] for e in har['log']['entries']))
            calls = [json.loads(line) for line in (root / 'calls.jsonl').read_text().splitlines()]
            self.assertEqual(calls[-1]['name'], 'browser_close')
            demo = json.loads((root / 'flows/test/demo.json').read_text())
            if mode in ('final_snapshot_error', 'snapshot_error'):
                self.assertIsNone(demo['final_snapshot'])
                self.assertIn('Target page has been closed', demo['warnings'][-1])
                snapshot_positions = [i for i, c in enumerate(calls) if c['name'] == 'browser_snapshot']
                dump_positions = [i for i, c in enumerate(calls) if c['name'] == 'browser_network_request']
                self.assertGreater(snapshot_positions[-1], max(dump_positions))
            if mode == 'retry':
                self.assertEqual(sum(c['name'] == 'browser_network_request' and c['args'].get('index') == 3 and c['args'].get('part') == 'response-body' for c in calls), 2)

    async def test_backend_owns_recording_until_finish(self):
        await self.run_recording('normal')

    async def test_missing_body_retried_before_close(self):
        await self.run_recording('retry')

    async def test_permanent_missing_body_stops_pipeline(self):
        await self.run_recording('missing')


    async def test_final_snapshot_failure_preserves_validated_har(self):
        await self.run_recording('final_snapshot_error')

    async def test_both_snapshots_optional(self):
        await self.run_recording('snapshot_error')

    async def test_tool_error_retains_diagnostic(self):
        client = McpClient(None)
        client.rpc = AsyncMock(return_value={'isError': True, 'content': [
            {'type': 'text', 'text': 'Target page has been closed'}]})
        with self.assertRaisesRegex(RecordingError, 'Target page has been closed'):
            await client.call('browser_snapshot', {})

    async def test_rpc_error_retains_diagnostic(self):
        process = SimpleNamespace(stdin=SimpleNamespace(write=lambda data: None, drain=AsyncMock()),
            stdout=SimpleNamespace(readline=AsyncMock(return_value=
                b'{"id":1,"error":{"code":-32000,"message":"Session disconnected"}}\n')))
        with self.assertRaisesRegex(RecordingError, 'Session disconnected'):
            await McpClient(process).rpc('tools/list')

    async def test_snapshot_timeout_is_warning(self):
        client = SimpleNamespace(call=AsyncMock(side_effect=TimeoutError()))
        warnings = []
        self.assertIsNone(await optional_snapshot(client, warnings, 'Final', lambda _: None))
        self.assertIn('TimeoutError', warnings[0])

    def test_manifest_preserves_nonconsecutive_ids(self):
        self.assertEqual(manifest_ids('3. [POST] /login\n7. [GET] /items'), [3, 7])
        with self.assertRaises(RecordingError):
            manifest_ids('unknown format')

    async def test_failed_recording_never_launches_agent(self):
        from backend.runtime.crew_runner import CrewConfig, run_crew
        with tempfile.TemporaryDirectory() as temp:
            config = CrewConfig(target_url='http://fixture.test', flow_name='test',
                run_dir=temp, crew_dir=str(ROOT / 'crew'), mcp_config='unused.json',
                claude_bin='claude', model='test', api_key='', display=':0',
                phase_timeout=10, overall_timeout=10)
            with patch('backend.runtime.crew_runner.record', AsyncMock(side_effect=RecordingError('Incomplete body capture'))), patch('backend.runtime.crew_runner.asyncio.create_subprocess_exec', AsyncMock()) as spawn:
                result = await run_crew(config, lambda event: None)
                spawn.assert_not_called()
                self.assertIn('Incomplete body capture', result['error'])
