# FlowBusters POC update

This package is based on the repository's current `main` plus the prepared POC changes.

## Apply

1. Make a backup or create a Git branch on the machine that runs FlowBusters.
2. Extract this ZIP into the FlowBusters repository root and allow matching files to be replaced.
3. Restart the backend and frontend.
4. Run one assessment against the deliberately vulnerable test application.

Do not copy `.env` or credentials between machines. This archive contains source files only.

## What to verify

- The browser still opens and the workflow can be completed.
- After **Finish recording**, `flows/<flow>/har_data/` contains request detail logs and separate response-body files.
- `flows/<flow>/recording.har` contains non-empty `response.content.text` for successful JSON API responses.
- The report shows verification status before severity.
- The delete-from-APPROVED case is `Confirmed` only when the before/after reads prove that the item disappeared.
- A `200` response with no state change is not confirmed.
- A failed state read is shown as a check error or needs review.

`runs/<run>/startup_timing.json` continues to measure startup. The supplied timing showed that the browser process itself appeared about 0.7 seconds after the first browser tool request; the remaining startup delay occurs before that request.

## Local validation completed

- Python unit tests: 14 passed.
- Frontend TypeScript and Vite production build: passed.
- HAR fixture: separate Playwright MCP response-body capture is preserved.
- Verification fixtures: `200` without deletion is not a finding; `500` with observed deletion is confirmed.
