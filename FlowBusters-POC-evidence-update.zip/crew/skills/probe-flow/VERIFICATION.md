# State verification, version 1

HTTP codes describe responses, not business-rule enforcement. Capture an
independent post-action read even when the action returns 500. Never infer
removal from 404. Unsupported checks remain NEEDS_REVIEW; do not invent evidence.

First supported predicate: approved_item_must_remain.
Record `verification` on the finding or on exactly one result with a matching
`finding_id`. Stable finding IDs also identify remediation sections.

Verification object:
- predicate: approved_item_must_remain
- rule: {source: user | specification, reference: actual supplied rule or spec location}
- before and after: {resource_id, principal_id, sequence: integer,
  status_code: 200, complete: true, state: APPROVED, item_ids: [IDs],
  request: captured request, response: captured response}
- action: {resource_id, principal_id, sequence: integer, method: DELETE,
  item_id: ID, request: captured request, response: captured response}
- error: optional description of a failed state check

Write a probe that reads the same complete collection before and after the
DELETE, using the same authenticated principal. Parse item IDs and approval
state from the captured response, not from agent assumptions. Use increasing
sequence numbers. Mark complete only when pagination is exhausted. Use an
isolated test resource without concurrent writers; otherwise the result is
inconclusive. If the application exposes no reliable state reader, emit
NEEDS_REVIEW. Do not create generic guessed URLs.

The backend compares the structured snapshots deterministically. It trusts
probe-provided captures and their normalized fields; this is not independent
re-execution or cryptographic evidence verification. App-specific extraction
must be tested against the target fixture. Additional predicates require code
and tests before they can return CONFIRMED.

An inferred rule needs user/specification confirmation before CONFIRMED.
Use explicit finding.remediation or headings with exact finding IDs.

Use backend.runtime.verification.capture_deletion_check with app-specific
read_state and delete_item callbacks when the backend package is importable.
It captures before/action/after and attempts the final read even after an
action exception. Otherwise reproduce that sequence in the standalone probe.
