"""Conservative report gate. HTTP status never determines a verdict.

The first supported predicate is approved-item deletion. Snapshots must be
captured by a probe; this module evaluates evidence, it does not fetch state.
"""
from copy import deepcopy


def classify(record):
    v = record.get('verification')
    if not isinstance(v, dict):
        return ('CHECK_ERROR', 'Probe execution failed.') if record.get('error_message') or record.get('outcome') in ('ERROR', 'CHECK_ERROR') else ('NEEDS_REVIEW', 'No supported state verification recorded.')
    if v.get('error'):
        return 'CHECK_ERROR', 'State verification failed: ' + str(v['error'])
    if v.get('predicate') != 'approved_item_must_remain':
        return 'NEEDS_REVIEW', 'Unsupported verification predicate.'
    rule = v.get('rule', {})
    if not isinstance(rule, dict) or rule.get('source') not in ('user', 'specification') or not rule.get('reference'):
        return 'NEEDS_REVIEW', 'The business rule needs an explicit user or specification reference.'
    before, after, action = (v.get(k) for k in ('before', 'after', 'action'))
    if not all(isinstance(x, dict) for x in (before, after, action)):
        return 'NEEDS_REVIEW', 'Before, action and after evidence are required.'
    for snapshot in (before, after):
        if snapshot.get('status_code') != 200 or snapshot.get('complete') is not True:
            return 'CHECK_ERROR', 'A complete successful state read is required; 404 is not deletion proof.'
        if not isinstance(snapshot.get('item_ids'), list) or not snapshot.get('request') or not snapshot.get('response'):
            return 'NEEDS_REVIEW', 'State snapshot lacks captured request/response or item IDs.'
    for key in ('resource_id', 'principal_id'):
        if not before.get(key) or before.get(key) != after.get(key) or before.get(key) != action.get(key):
            return 'NEEDS_REVIEW', 'Resource and authenticated principal must match across all observations.'
    times = [x.get('sequence') for x in (before, action, after)]
    if not all(type(t) is int for t in times) or not times[0] < times[1] < times[2]:
        return 'NEEDS_REVIEW', 'Evidence sequence is missing or inconsistent.'
    item = action.get('item_id')
    if before.get('state') != 'APPROVED' or after.get('state') != 'APPROVED' or item not in before['item_ids']:
        return 'NEEDS_REVIEW', 'Approved-state preconditions were not established or changed.'
    if action.get('method') != 'DELETE' or not action.get('request') or not action.get('response'):
        return 'NEEDS_REVIEW', 'Captured deletion action is required.'
    if item not in after['item_ids']:
        return 'CONFIRMED', 'Captured state reads show removal of an item while the resource remained approved.'
    return 'NOT_REPRODUCED', 'The item remained present in the captured post-action state.'


def normalize_report(report):
    """Return a copy; preserve raw artifacts and supplied IDs."""
    data = deepcopy(report)
    results = data.get('results') or []
    findings = data.get('findings')
    if not isinstance(findings, list):
        findings = [dict(r, title=r.get('script', 'Legacy finding'), source='MUTATION_SCRIPT', evidence=r.get('response_snippet') or '', cwe=[], severity='Not assessed') for r in results if r.get('outcome') == 'BUG_FOUND']
        findings += [dict(o, title=o.get('finding', 'Legacy observation'), source='ANALYSIS') for o in data.get('additional_observations', [])]
    for i, finding in enumerate(findings):
        finding.setdefault('id', f'F-{i+1:03}')
        linked = [r for r in results if r.get('finding_id') == finding['id']]
        if 'verification' not in finding and len(linked) == 1:
            finding['verification'] = deepcopy(linked[0].get('verification'))
            if linked[0].get('error_message'):
                finding['error_message'] = linked[0]['error_message']
        finding['verification_status'], finding['verification_reason'] = classify(finding)
    for result in results:
        result.setdefault('original_outcome', result.get('outcome'))
        result['outcome'], result['verification_reason'] = classify(result)
    counts = {s: sum(f['verification_status'] == s for f in findings) for s in ('CONFIRMED', 'NEEDS_REVIEW', 'NOT_REPRODUCED', 'CHECK_ERROR')}
    data['findings'], data['results'] = findings, results
    data['summary'] = {**(data.get('summary') or {}), 'reported_findings': len(findings),
        'bugs_found': counts['CONFIRMED'], 'confirmed': counts['CONFIRMED'],
        'needs_review': counts['NEEDS_REVIEW'], 'not_reproduced': counts['NOT_REPRODUCED'],
        'rejected': sum(r['outcome'] == 'NOT_REPRODUCED' for r in results),
        'errors': sum(r['outcome'] == 'CHECK_ERROR' for r in results) + counts['CHECK_ERROR']}
    data['verification_schema_version'] = 1
    return data


def capture_deletion_check(read_state, delete_item, *, rule, resource_id, principal_id, item_id):
    """Adapter helper: read_state returns captured normalized state; delete_item
    returns captured request/response even for HTTP errors (do not raise on 500).
    Callbacks use the authorized app's endpoints and same authenticated session.
    """
    verification = {'predicate': 'approved_item_must_remain', 'rule': rule}
    try:
        before = read_state()
        verification['before'] = {**before, 'sequence': 1}
    except Exception as exc:
        verification['error'] = f'Before-state read failed: {type(exc).__name__}'
        return {'verification': verification}
    # Never mutate if the authorized scenario preconditions were not observed.
    if (before.get('status_code') != 200 or before.get('complete') is not True
            or before.get('state') != 'APPROVED' or item_id not in before.get('item_ids', [])
            or before.get('resource_id') != resource_id or before.get('principal_id') != principal_id):
        verification['error'] = 'Preconditions not established; deletion was not executed.'
        return {'verification': verification}
    try:
        action = delete_item()
        verification['action'] = {**action, 'sequence': 2, 'method': 'DELETE',
            'resource_id': resource_id, 'principal_id': principal_id, 'item_id': item_id}
    except Exception as exc:
        verification['error'] = f'Action capture failed: {type(exc).__name__}'
    # Even a failed action may have changed state. Always attempt the read.
    try:
        verification['after'] = {**read_state(), 'sequence': 3}
    except Exception as exc:
        verification['error'] = f'After-state read failed: {type(exc).__name__}'
    return {'verification': verification}
