import json
import unittest
from unittest.mock import patch

from backend.runtime.state_lock_probe import run_probe
from backend.runtime.verification import classify


def state(parts):
    return json.dumps({"status": "APPROVED", "parts": [{"id": i} for i in parts]})


TARGET = {
    "base": "http://flowshop.test:18923",
    "parent_path": "/api/dashboard/1",
    "children_key": "parts",
    "child_delete_paths": ["/api/dashboard/1/parts"],
    "lifecycle_field": "status",
    "lifecycle_posts": [],
    "locked_states": ["APPROVED"],
    "cookie": "session=test",
    "login": None,
}


class StateLockProbeTests(unittest.TestCase):
    def test_500_with_observed_deletion_is_confirmed(self):
        replies = iter([
            (200, state([7, 8])),  # baseline
            (200, state([7, 8])),  # ensure_locked state read
            (200, state([7, 8])),  # before action
            (500, "server error"), # action
            (200, state([8])),     # after action
        ])
        with patch("backend.runtime.state_lock_probe._do_request", side_effect=lambda *a, **k: next(replies)):
            finding = run_probe(dict(TARGET))
        self.assertIsNotNone(finding)
        self.assertEqual(classify(finding)[0], "CONFIRMED")
        self.assertEqual(finding["verification"]["action"]["response"]["status_code"], 500)

    def test_200_without_observed_deletion_is_not_a_finding(self):
        replies = iter([
            (200, state([7, 8])),
            (200, state([7, 8])),
            (200, state([7, 8])),
            (200, '{"ok":true}'),
            (200, state([7, 8])),
        ])
        with patch("backend.runtime.state_lock_probe._do_request", side_effect=lambda *a, **k: next(replies)):
            finding = run_probe(dict(TARGET))
        self.assertIsNone(finding)


if __name__ == "__main__":
    unittest.main()
