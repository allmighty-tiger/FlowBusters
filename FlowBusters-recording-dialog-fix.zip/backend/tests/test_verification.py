import unittest
from copy import deepcopy
from backend.runtime.verification import classify, normalize_report, capture_deletion_check


def example(status=200, removed=True):
    before = dict(resource_id='r1', principal_id='u1', sequence=1, status_code=200,
        complete=True, state='APPROVED', item_ids=[1, 2], request={'method':'GET'}, response={'items':[1,2]})
    after = {**deepcopy(before), 'sequence':3, 'item_ids':[2] if removed else [1,2]}
    return {'verification': {'predicate':'approved_item_must_remain',
        'rule': {'source':'user', 'reference':'Approved items cannot be deleted'},
        'before':before, 'after':after,
        'action':dict(resource_id='r1', principal_id='u1', sequence=2, method='DELETE', item_id=1,
            request={'method':'DELETE'}, response={'status_code':status})}}


class VerificationTests(unittest.TestCase):
    def test_capture_reads_after_500(self):
        v=example(500)['verification']; snapshots=iter([v['before'],v['after']])
        r=capture_deletion_check(lambda: next(snapshots), lambda: v['action'],
            rule=v['rule'],resource_id='r1',principal_id='u1',item_id=1)
        self.assertEqual(classify(r)[0], 'CONFIRMED')
    def test_capture_reads_after_exception(self):
        v=example()['verification']; calls=[]
        def read():
            calls.append(1); return v['before'] if len(calls)==1 else v['after']
        def fail(): raise TimeoutError()
        r=capture_deletion_check(read,fail,rule=v['rule'],resource_id='r1',principal_id='u1',item_id=1)
        self.assertEqual(len(calls),2)
        self.assertEqual(classify(r)[0], 'CHECK_ERROR')
    def test_200_without_change(self):
        self.assertEqual(classify(example(200, False))[0], 'NOT_REPRODUCED')
    def test_500_with_change(self):
        self.assertEqual(classify(example(500))[0], 'CONFIRMED')
    def test_failed_state_read(self):
        r=example(); r['verification']['after']['status_code']=404
        self.assertEqual(classify(r)[0], 'CHECK_ERROR')
    def test_missing_and_inferred_evidence(self):
        self.assertEqual(classify({'outcome':'BUG_FOUND','status_code':200})[0], 'NEEDS_REVIEW')
        r=example();r['verification']['rule']['source']='agent'
        self.assertEqual(classify(r)[0], 'NEEDS_REVIEW')
    def test_wrong_identity_and_order(self):
        for key,value in [('principal_id','other'),('sequence',0)]:
            r=example();r['verification']['after'][key]=value
            self.assertEqual(classify(r)[0], 'NEEDS_REVIEW')
    def test_linkage_and_legacy(self):
        r={'findings':[{'id':'F-1'}], 'results':[{**example(), 'finding_id':'F-1'}]}
        n=normalize_report(r)
        self.assertEqual(n['findings'][0]['verification_status'],'CONFIRMED')
        self.assertNotIn('verification',r['findings'][0])
        old=normalize_report({'results':[{'outcome':'BUG_FOUND','script':'old'}]})
        self.assertEqual(old['summary']['confirmed'],0)
        self.assertEqual(old['findings'][0]['verification_status'],'NEEDS_REVIEW')

if __name__ == '__main__': unittest.main()
