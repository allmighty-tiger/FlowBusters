# Recorder dialog waiting update

Consolidated update; includes all earlier recording, evidence, status and report changes.
Stop the backend, extract from the repository root:
unzip -o FlowBusters-recording-dialog-fix.zip

Run:
python -m unittest discover -s backend/tests -q

Restart backend and begin a NEW assessment.
After Finish Recording, if a dialog is open, the event log asks you to resolve it in the recording browser.
Choose OK or Cancel yourself. Capture retries every 2 seconds, for up to 120 seconds
(subject to the overall run timeout). No automatic dialog decisions are made.
If time expires, recording fails with a specific explanation.
Snapshot reads remain optional and retain their shorter 10-second budget.
Network capture and HAR validation remain mandatory.

See RECORDING-UPDATE-INSTALL.md for full installation requirements.
Validation: offline tests; real browser run must be checked on your computer.
