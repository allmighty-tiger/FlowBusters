# Consolidated FlowBusters POC update

This archive includes the previous prepared report, HAR, verification,
Not executed and startup changes plus the backend-owned recording update.
Apply this ONE archive to the existing POC checkout; earlier ZIPs are not needed.
It is an update package, not a complete standalone repository.

1. Stop the backend and frontend. Save any local edits in your POC branch.
2. Extract this ZIP into the repository root. Review matching-file replacements.
3. Use Python 3.11 or newer. Run `python3 -m unittest discover -s backend/tests -q`.
4. In frontend run `npm run build`, then restart both services.
5. Use a NEW flow name and an explicitly authorized non-production target.

Recording now starts before the AI process. Backend owns the existing configured
Playwright MCP stdio command and session, waits for Finish Recording, fetches each
listed request's details and bodies by ID, validates HAR, then closes the browser.
Only then does it start the agent at ANALYZE with browser MCP disabled.
It records initial/final accessibility snapshots and HTTP traffic, not a detailed
UI click trace. Old Recorder prompt instructions are no longer sent to the agent.

Configuration: mcp.json must contain mcpServers.playwright.command and args for
the local stdio MCP server (HTTP/SSE remote MCP is unsupported). Tested tool schema:
@playwright/mcp 0.0.77. Keep your configured Chrome/display/certificate options.
scope.json must explicitly allow the target host/origin and path. With
block_production enabled, this recorder fails closed because the current scope
schema has no machine-verifiable production classification. Configure scope for
the authorized test environment deliberately; do not bypass organizational policy.

Missing bodies receive a bounded retry while the MCP session is still alive.
If capture still fails, analysis is not started. Partial files and the exact
missing IDs remain in har_data/capture_manifest.json. Failure cleanup terminates
the recording session; it does not claim a failed recording was secured.

Validation: 30 Python tests, including a real subprocess running a simulated MCP
server and a check that failed recording cannot launch the agent. Actual installed
MCP initialize/tools-list compatibility was checked without launching Chrome.
End-to-end headed Chrome + user workflow + live AI assessment still requires a
run on your computer. This package does not claim that environment test passed.

Expected: browser opens without waiting for the model; stays open until Finish;
recording_validated.marker is written only after HAR validation and browser close;
analysis starts afterward. Do not edit the deliberately vulnerable test app.
