# Recorder snapshot fix

This consolidated archive replaces FlowBusters-recording-complete-update.zip.
Apply from the repository root after stopping the backend:
unzip -o FlowBusters-recording-snapshot-fix.zip

Then run:
python -m unittest discover -s backend/tests -v

Restart the backend using your usual command and start a NEW assessment.

Changes:
- Save and validate the HAR before the final page snapshot.
- Initial and final snapshots are optional, with a 10-second timeout.
- Missing snapshots are null in demo.json; warnings explain the failure.
- MCP tool/RPC failures retain bounded diagnostic details with basic credential redaction.
- Network capture validation remains mandatory.

Validation: 35 offline backend tests passed, including failed snapshots and MCP errors.
A live headed-browser assessment has not been verified here.
For the complete update's installation requirements, see RECORDING-UPDATE-INSTALL.md.
